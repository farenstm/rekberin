import { expect } from "chai";
import { ethers } from "hardhat";
import type { EscrowChain } from "../typechain-types";
import type { HardhatEthersSigner } from "@nomicfoundation/hardhat-ethers/signers";

describe("EscrowChain", function () {
  let escrow: EscrowChain;
  let seller: HardhatEthersSigner;
  let buyer: HardhatEthersSigner;
  let outsider: HardhatEthersSigner;

  const price = ethers.parseEther("1");
  const cid = "bafybeigdyrzt5sfp7udm7hu76uh7y26nf3gq2wz5uxn3k2a";

  beforeEach(async function () {
    [, seller, buyer, outsider] = await ethers.getSigners();
    const factory = await ethers.getContractFactory("EscrowChain");
    escrow = await factory.deploy();
    await escrow.waitForDeployment();
  });

  async function createListing() {
    await escrow.connect(seller).createListing(price, cid);
  }

  async function createHeldEscrow() {
    await createListing();
    await escrow.connect(buyer).createEscrow(1, { value: price });
  }

  describe("Listing management", function () {
    it("creates an active listing and emits ListingCreated", async function () {
      await expect(escrow.connect(seller).createListing(price, cid))
        .to.emit(escrow, "ListingCreated")
        .withArgs(1, seller.address, price, cid);

      const listing = await escrow.getListing(1);
      expect(listing.id).to.equal(1);
      expect(listing.seller).to.equal(seller.address);
      expect(listing.price).to.equal(price);
      expect(listing.cid).to.equal(cid);
      expect(listing.isActive).to.equal(true);
    });

    it("rejects a zero price", async function () {
      await expect(
        escrow.connect(seller).createListing(0, cid),
      ).to.be.revertedWith("Price must be greater than 0");
    });

    it("rejects an empty CID", async function () {
      await expect(
        escrow.connect(seller).createListing(price, ""),
      ).to.be.revertedWith("CID required");
    });

    it("allows only the seller to update an active listing", async function () {
      await createListing();
      const newPrice = ethers.parseEther("2");
      const newCid = `${cid}-updated`;

      await expect(escrow.connect(seller).updateListing(1, newPrice, newCid))
        .to.emit(escrow, "ListingUpdated")
        .withArgs(1, newPrice, newCid);

      const listing = await escrow.getListing(1);
      expect(listing.price).to.equal(newPrice);
      expect(listing.cid).to.equal(newCid);

      await expect(
        escrow.connect(outsider).updateListing(1, price, cid),
      ).to.be.revertedWith("Only seller can update listing");
    });

    it("allows only the seller to cancel an active listing", async function () {
      await createListing();
      await expect(escrow.connect(seller).cancelListing(1))
        .to.emit(escrow, "ListingCancelled")
        .withArgs(1);

      expect((await escrow.getListing(1)).isActive).to.equal(false);
    });
  });

  describe("Escrow creation", function () {
    beforeEach(createListing);

    it("creates HELD escrow, locks funds, and deactivates the listing", async function () {
      await expect(escrow.connect(buyer).createEscrow(1, { value: price }))
        .to.emit(escrow, "EscrowCreated")
        .withArgs(1, 1, buyer.address, seller.address, price);

      const transaction = await escrow.getEscrow(1);
      expect(transaction.buyer).to.equal(buyer.address);
      expect(transaction.seller).to.equal(seller.address);
      expect(transaction.amount).to.equal(price);
      expect(transaction.state).to.equal(0);
      expect(await ethers.provider.getBalance(await escrow.getAddress())).to.equal(price);
      expect((await escrow.getListing(1)).isActive).to.equal(false);
    });

    it("rejects an incorrect payment amount", async function () {
      await expect(
        escrow.connect(buyer).createEscrow(1, { value: ethers.parseEther("0.5") }),
      ).to.be.revertedWith("Incorrect MATIC value sent");
    });

    it("rejects purchase of the seller's own listing", async function () {
      await expect(
        escrow.connect(seller).createEscrow(1, { value: price }),
      ).to.be.revertedWith("Seller cannot buy own listing");
    });

    it("rejects a second purchase of the same listing", async function () {
      await escrow.connect(buyer).createEscrow(1, { value: price });
      await expect(
        escrow.connect(outsider).createEscrow(1, { value: price }),
      ).to.be.revertedWith("Listing is not active");
    });
  });

  describe("FSM and authorization", function () {
    beforeEach(createHeldEscrow);

    it("transitions HELD to RELEASED and pays the seller", async function () {
      const balanceBefore = await ethers.provider.getBalance(seller.address);

      await expect(escrow.connect(buyer).confirmReceipt(1))
        .to.emit(escrow, "EscrowStateChanged")
        .withArgs(1, 0, 1);

      expect((await escrow.getEscrow(1)).state).to.equal(1);
      expect((await ethers.provider.getBalance(seller.address)) - balanceBefore).to.equal(price);
      expect(await ethers.provider.getBalance(await escrow.getAddress())).to.equal(0);
    });

    it("allows only the buyer to confirm receipt", async function () {
      await expect(
        escrow.connect(outsider).confirmReceipt(1),
      ).to.be.revertedWith("Only buyer can confirm receipt");
    });

    it("transitions HELD to REFUND_REQUESTED", async function () {
      await expect(escrow.connect(buyer).requestRefund(1))
        .to.emit(escrow, "EscrowStateChanged")
        .withArgs(1, 0, 2);
      expect((await escrow.getEscrow(1)).state).to.equal(2);
    });

    it("allows only the buyer to request a refund", async function () {
      await expect(
        escrow.connect(outsider).requestRefund(1),
      ).to.be.revertedWith("Only buyer can request refund");
    });

    it("transitions REFUND_REQUESTED to REFUNDED and repays the buyer", async function () {
      await escrow.connect(buyer).requestRefund(1);
      const balanceBefore = await ethers.provider.getBalance(buyer.address);

      await expect(escrow.connect(seller).approveRefund(1))
        .to.emit(escrow, "EscrowStateChanged")
        .withArgs(1, 2, 3);

      expect((await escrow.getEscrow(1)).state).to.equal(3);
      expect((await ethers.provider.getBalance(buyer.address)) - balanceBefore).to.equal(price);
    });

    it("transitions REFUND_REQUESTED back to HELD when rejected", async function () {
      await escrow.connect(buyer).requestRefund(1);
      await expect(escrow.connect(seller).rejectRefund(1))
        .to.emit(escrow, "EscrowStateChanged")
        .withArgs(1, 2, 0);
      expect((await escrow.getEscrow(1)).state).to.equal(0);
    });

    it("allows only the seller to approve or reject refunds", async function () {
      await escrow.connect(buyer).requestRefund(1);
      await expect(
        escrow.connect(outsider).approveRefund(1),
      ).to.be.revertedWith("Only seller can approve refund");
      await expect(
        escrow.connect(outsider).rejectRefund(1),
      ).to.be.revertedWith("Only seller can reject refund");
    });

    it("rejects actions that are invalid for the current state", async function () {
      await expect(
        escrow.connect(seller).approveRefund(1),
      ).to.be.revertedWith("Refund not requested");
      await expect(
        escrow.connect(seller).rejectRefund(1),
      ).to.be.revertedWith("Refund not requested");

      await escrow.connect(buyer).confirmReceipt(1);
      await expect(
        escrow.connect(buyer).confirmReceipt(1),
      ).to.be.revertedWith("Escrow is not HELD");
      await expect(
        escrow.connect(buyer).requestRefund(1),
      ).to.be.revertedWith("Escrow is not HELD");
    });

    it("keeps REFUNDED as a terminal state", async function () {
      await escrow.connect(buyer).requestRefund(1);
      await escrow.connect(seller).approveRefund(1);
      await expect(
        escrow.connect(buyer).confirmReceipt(1),
      ).to.be.revertedWith("Escrow is not HELD");
      await expect(
        escrow.connect(buyer).requestRefund(1),
      ).to.be.revertedWith("Escrow is not HELD");
    });
  });
});
